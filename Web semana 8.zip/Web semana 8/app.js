fetch('http://localhost:3005/posts')
    .then(response => response.json())
    .then(data => {

        for (let i = 0; i < data.length; i++) {
            const carroData = data[i];
            const miCarro = document.createElement('card-container');
            miCarro.setAttribute('name', carroData.name);
            miCarro.setAttribute('image', carroData.image);
            miCarro.setAttribute('description', carroData.description);
            miCarro.setAttribute('price', carroData.price);
            document.body.appendChild(miCarro);
            console.log(miCarro);
            
            
        }

        // for (let i = 0; i < data.length; i++) {
        //     const carroData = data[i];
        //     console.log(carroData.name);
        //     console.log(carroData.image);
        //     console.log(carroData.description);
        // }

    })
    
    .catch(error => console.error(error));





class MyCard extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        
    fetch ('http://localhost:3005/posts')
    .then(response => response.json())
    .then(data => {
        for (let i = 0; i < data.length; i++) {
            const carroData = data[i];
            this.innerHTML = `
        <section class="card-container">

        <div class="image-container">
            <img src=${carroData.image}>
        </div>

        <div class="text-container">
            <h2>${carroData.name}</h2>
            <p class="title">Chevrolet</p>
            <p class="biography">${carroData.description}
            <p class="price">${carroData.price}</p>
        </div>

        </section>
    `;
    
        }
    })

    .catch(error => console.error(error));

        
    }

}
customElements.define('card-container', MyCard);




